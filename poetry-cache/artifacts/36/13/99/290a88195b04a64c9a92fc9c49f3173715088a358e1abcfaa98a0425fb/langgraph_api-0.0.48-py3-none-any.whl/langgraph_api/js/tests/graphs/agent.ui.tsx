import "./agent.css";
import React from "react";

export function StockPrice() {
  return <div>Stock Price</div>;
}

export default {
  "stock-price": StockPrice,
} as const;
